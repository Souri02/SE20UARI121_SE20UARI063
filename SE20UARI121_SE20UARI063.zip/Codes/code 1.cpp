#include "UnityPluginInterface.h"


extern "C" void UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API UnityPluginLoad(IUnityInterfaces* unityInterfaces);
extern "C" void UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API UnityPluginUnload();

static IUnityInterfaces* s_UnityInterfaces = nullptr;


static IUnityGraphics* s_Graphics = nullptr;


struct F1carObject
{
    float position[3];
    float scale[3];
};


extern "C" void UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API UnitySetGraphicsDevice(void* device, int deviceType, int eventType);


extern "C" void UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API UnityRenderEvent(int eventID);

extern "C" void UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API UnityPluginLoad(IUnityInterfaces* unityInterfaces)
{
    s_UnityInterfaces = unityInterfaces;
    s_Graphics = s_UnityInterfaces->Get<IUnityGraphics>();
}


extern "C" void UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API UnityPluginUnload()
{
    
}


extern "C" void UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API UnitySetGraphicsDevice(void* device, int deviceType, int eventType)
{
    
}


extern "C" void UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API UnityRenderEvent(int eventID)
{
    
    if (eventID == 0)
    {
        F1carObject F1car;
        F1car.position[0] = 0.0f;
        F1car.position[1] = 0.0f;
        F1car.position[2] = 0.0f;
        F1car.scale[0] = 1.0f;
        F1car.scale[1] = 1.0f;
        F1car.scale[2] = 1.0f;

        // Call a function to render the F1car
        RenderF1car(F1car);
    }
}


void RenderF1car(const F1carObject& F1car)
{
 
}
