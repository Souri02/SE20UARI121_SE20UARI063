#include <GL/gl.h>
#include <GL/glut.h>


void RenderF1Car()
{
    

    glutSolidF1 car(1.0); 

}


extern "C" void UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API UnitySetGraphicsDevice(void* device, int deviceType, int eventType)
{
    


extern "C" void UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API UnityRenderEvent(int eventID)
{
    
    if (eventID == 0)
    {
       
        RenderF1Car();
    }
}
